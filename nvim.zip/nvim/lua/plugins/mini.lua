return {
   { 'echasnovski/mini.nvim', version = '*' },
}
