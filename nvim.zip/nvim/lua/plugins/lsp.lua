--return {
--	{'neovim/nvim-lspconfig'},
--	{'hrsh7th/cmp-nvim-lsp'},
--	{'hrsh7th/nvim-cmp'},
--
--}
return {
  'neovim/nvim-lspconfig',
  dependencies = { 'saghen/blink.cmp' },

  -- example calling setup directly for each LSP
  config = function()
    local capabilities = require('blink.cmp').get_lsp_capabilities()
    local lspconfig = require('lspconfig')

    lspconfig['lua_ls'].setup({ capabilities = capabilities })
    lspconfig['ltex_plus'].setup({ capabilities = capabilities })
    lspconfig['sourcekit'].setup({ capabilities = capabilities })
    lspconfig['leanls'].setup({ capabilities = capabilities })
    lspconfig['pyright'].setup({capabilities = capabilities})
  end,
  enabled = false,
}
