return {
   "ggandor/leap.nvim",
}
