require("config.set")
require("config.remap")
require("config.lazy")

require('mini.ai').setup()
require('mini.comment').setup()
require('mini.statusline').setup()
require('todo-comments').setup()

-- Leap configuration
-- vim.keymap.set({'n', 'x'}, 'f', '<Plug>(leap)')
vim.keymap.set({'n', 'x', 'o'}, 's',  '<Plug>(leap-forward)')
vim.keymap.set({'n', 'x', 'o'}, 'r',  '<Plug>(leap-backward)')
-- Define equivalence classes for brackets and quotes, in addition to
-- the default whitespace group:
require('leap').opts.equivalence_classes = { ' \t\r\n', '([{', ')]}', '\'"`' }

-- Define a preview filter (skip the middle of alphanumeric words):
require('leap').opts.preview_filter =
  function (ch0, ch1, ch2)
    return not (
      ch1:match('%s') or
      ch0:match('%w') and ch1:match('%w') and ch2:match('%w')
    )
  end


-- if Comment is saturated.
vim.api.nvim_set_hl(0, 'LeapBackdrop', { link = 'Comment' })
vim.api.nvim_set_hl(0, 'LeapLabel', { link = 'String' })

-- Colorscheme
vim.cmd.colorscheme "catppuccin"

-- LSP
local capabilities = {
	textDocument = {
		foldingRange = {
			dynamicRegistration = false,
			lineFoldingOnly = true,
		},
	},
}

capabilities = require("blink.cmp").get_lsp_capabilities(capabilities)

-- Setup language servers.

vim.lsp.config("*", {
	capabilities = capabilities,
})
vim.lsp.enable({'luals'})
vim.lsp.enable({'pyright'})



-- AUTOCOMMANDS
