vim.keymap.set({"n", "v"}, "J", "<C-d>zz")
vim.keymap.set({"n", "v"}, "K", "<C-u>zz")
vim.keymap.set({"n","v"}, "H", "_")
vim.keymap.set({"n","v"}, "L", "$")
vim.keymap.set({"n","v"}, "t", "f")

vim.keymap.set({"n"}, "<leader>d", function() vim.diagnostic.open_float() end )
vim.keymap.set("n", "<leader>w", ":w<CR>" )
