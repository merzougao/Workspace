local cmp = require('cmp')

cmp.setup({
    sources = {
        {name = 'nvim_lsp'},
        { name = "buffer"},
        { name = "path" },
    },
    snippet = {
        expand = function(args)
            -- You need Neovim v0.10 to use vim.snippet
            vim.snippet.expand(args.body)
        end,
    },
    mapping = cmp.mapping.preset.insert({
        ["<CR>"] = cmp.mapping.confirm({ select = true }),
        ["<tab>"] = cmp.mapping(function(original)
            if cmp.visible() then
                cmp.select_next_item() -- run completion selection if completing
            else
                original()      -- run the original behavior if not completing
            end
        end, {"i", "s"}),
        ["<S-tab>"] = cmp.mapping(function(original)
            if cmp.visible() then
                cmp.select_prev_item()
            else
                original()
            end
        end, {"i", "s"}),
    }),
})
